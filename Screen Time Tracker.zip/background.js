let screenTime = 0;

setInterval(() => {
    screenTime++;
    chrome.storage.local.set({ screenTime });
}, 60000);

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ screenTime: 0 });

    chrome.alarms.create('hourlyReminder', {
        periodInMinutes: 60
    });
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'hourlyReminder') {
        chrome.notifications.create({
            title: 'Screen Time Reminder',
            message: 'You have been browsing for an hour. Maybe take a break?',
            iconUrl: 'icons/icon48.png',
            type: 'basic'
        });
    }
});
