chrome.storage.local.get(['screenTime'], function(result) {
    const hours = Math.floor(result.screenTime / 60);
    const minutes = result.screenTime % 60;
    document.getElementById('time-display').textContent = `${hours}h ${minutes}m`;
});
